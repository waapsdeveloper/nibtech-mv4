<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect_uri' => env('GOOGLE_REDIRECT_URI'),
    ],

    'backmarket' => [
        'base_url' => env('BACKMARKET_BASE_URL', 'https://www.backmarket.fr/ws/'),
        'care_send_attachments' => filter_var(
            env('BACKMARKET_CARE_ATTACHMENTS', false),
            FILTER_VALIDATE_BOOLEAN,
            FILTER_NULL_ON_FAILURE
        ) ?? false,
    ],

    'refurbed' => [
        'base_url' => env('REFURBED_API_BASE_URL', 'https://api.refurbed.com'),
        'api_key' => env('REFURBED_API_KEY'),
        'auth_scheme' => env('REFURBED_AUTH_SCHEME', 'Bearer'),
        'user_agent' => env('REFURBED_USER_AGENT'),
        'timeout' => env('REFURBED_TIMEOUT', 30),
        'max_retries' => env('REFURBED_MAX_RETRIES', 3),
        'retry_delay_ms' => env('REFURBED_RETRY_DELAY_MS', 250),
        'log_channel' => env('REFURBED_LOG_CHANNEL'),
        'source_system' => env('REFURBED_SOURCE_SYSTEM', 'nibritaintech'),
        'webhook_secret' => env('REFURBED_WEBHOOK_SECRET'),
        'shipping' => [
            'default_merchant_address_id' => env('REFURBED_SHIPPING_MERCHANT_ADDRESS_ID'),
            'default_weight' => env('REFURBED_SHIPPING_DEFAULT_WEIGHT', 0.5),
            'default_carrier' => env('REFURBED_SHIPPING_DEFAULT_CARRIER'),
            'auto_label_on_accept' => filter_var(
                env('REFURBED_SHIPPING_AUTO_LABEL_ON_ACCEPT', true),
                FILTER_VALIDATE_BOOLEAN,
                FILTER_NULL_ON_FAILURE
            ) ?? true,
            'address' => [
                'company' => env('REFURBED_SHIPPING_COMPANY'),
                'street' => env('REFURBED_SHIPPING_STREET'),
                'house_number' => env('REFURBED_SHIPPING_HOUSE_NUMBER'),
                'postal_code' => env('REFURBED_SHIPPING_POSTAL_CODE'),
                'city' => env('REFURBED_SHIPPING_CITY'),
                'country' => env('REFURBED_SHIPPING_COUNTRY'),
                'contact_person' => env('REFURBED_SHIPPING_CONTACT_PERSON'),
                'phone' => env('REFURBED_SHIPPING_PHONE'),
                'email' => env('REFURBED_SHIPPING_EMAIL'),
                'pickup_instructions' => env('REFURBED_SHIPPING_PICKUP_INSTRUCTIONS'),
            ],
        ],
        'support' => [
            'chat_url' => env('REFURBED_SUPPORT_CHAT_URL', 'https://refurbed.zendesk.com/agent/tickets/new'),
            'docs_url' => env('REFURBED_SUPPORT_DOC_URL'),
            'chat_hint' => env(
                'REFURBED_SUPPORT_CHAT_HINT',
                'Share the Refurbed order reference when you open a Zendesk chat.'
            ),
            'chat_context_template' => env(
                'REFURBED_SUPPORT_CHAT_TEMPLATE',
                "Refurbed order :reference_id\nMarketplace reference: :reference\nCustomer: :customer\nIssue: "
            ),
        ],
        'gmail_ticket_query' => env(
            'REFURBED_ZENDESK_QUERY',
            'subject:"refurbed inquiry" OR from:refurbed-merchant.zendesk.com'
        ),
        'gmail_ticket_labels' => array_values(array_filter(explode(
            ',',
            env('REFURBED_ZENDESK_LABELS', 'INBOX')
        ))),
        'gmail_ticket_max_results' => (int) env('REFURBED_ZENDESK_MAX_RESULTS', 50),
        'gmail_ticket_max_age_minutes' => (int) env('REFURBED_ZENDESK_MAX_AGE_MINUTES', 1440),
        'gmail_ticket_max_pages' => (int) env('REFURBED_ZENDESK_MAX_PAGES', 0),
    ],

    'dhl' => [
        'base_url' => env('DHL_API_BASE_URL', 'https://api.dhl.com/mydhlapi/test'),
        'auth_url' => env('DHL_AUTH_URL', 'https://api.dhl.com/mydhlapi/oauth/token'),
        'client_id' => env('DHL_CLIENT_ID'),
        'client_secret' => env('DHL_CLIENT_SECRET'),
        'account_number' => env('DHL_ACCOUNT_NUMBER'),
        'preferred_language' => env('DHL_PREFERRED_LANGUAGE'),
        'timeout' => env('DHL_TIMEOUT', 30),
        'max_retries' => env('DHL_MAX_RETRIES', 3),
        'retry_delay_ms' => env('DHL_RETRY_DELAY_MS', 250),
        'token_ttl' => env('DHL_TOKEN_TTL', 3500),
        'cache_store' => env('DHL_CACHE_STORE'),
        'log_channel' => env('DHL_LOG_CHANNEL'),
    ],

    'tenor' => [
        'api_key' => env('TENOR_API_KEY'),
        'limit' => (int) env('TENOR_SEARCH_LIMIT', 12),
    ],

];
